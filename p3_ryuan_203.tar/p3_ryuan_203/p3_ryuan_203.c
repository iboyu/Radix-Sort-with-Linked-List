#include <stdio.h>
#include <stdlib.h>
#define B 10

typedef struct Node
{
    int data;
    struct Node *next;
} ListNode;

ListNode *newList(void)
{
    ListNode *list = (ListNode *)malloc(sizeof(ListNode));
    if (list == NULL)
    {
        printf("Malloc failed. Exit.");
        exit(-1);
    }
    list->data = 0;
    list->next = NULL;
    return list;
}

ListNode *insertNode(ListNode *prev, int data)
{
    ListNode *nNode = newList();
    nNode->data = data;
    if (prev->next == NULL)
    {
        prev->next = nNode;
    }
    else
    {
        nNode->next = prev->next;
        prev->next = nNode;
    }

    return prev;
}

ListNode *insertAtTail(ListNode *list, int data)
{
    ListNode *current, *tail;
    tail = list;
    current = newList();
    while (tail != NULL)
    {
        if (tail->next == NULL)
        {
            break;
        }
        tail = tail->next;
    }
    current->data = data;
    tail->next = current;
    tail = current;
    return list;
}

ListNode *removeNode(ListNode *prev)
{
    ListNode *current, *nextNode;
    current = prev;

    if (current != NULL && current->next != NULL)
    {

        nextNode = current->next;
        current->next = current->next->next; 
        nextNode->next = NULL;              
    }
    return nextNode;
}

ListNode *getRandomList(ListNode *list, int seed, int NumValus, int low, int high)
{
    int i, ranNum;
    for (i = 0; i < NumValus; i++)
    {
        ranNum = rand() % (high - low + 1) + low;
        list = insertNode(list, ranNum);
    }
    return list;
}

void printList(ListNode *list)
{
    ListNode *head = list;
    while (head->next != NULL)
    {
        head = head->next;
        printf("%i  ", head->data);
    }
    printf("\n");
}

int findMax(ListNode *list)
{
    int max = -1;
    ListNode *head = list;
    while (head->next != NULL)
    {
        head = head->next;
        if (head->data > max)
        {
            max = head->data;
        }
    }
    return max;
}

int findN(int max)
{
    int N = 0, num;
    num = max;
    while (num != 0)
    {
        num /= 10;
        N++;
    }
    return N;
}

int length(ListNode *list)
{
    ListNode *head = list;
    int length = 0;
    while (head->next != NULL)
    {
        head = head->next;
        length++;
    }
    return length;
}

void deleteList(ListNode *start)
{
    if (start->next != NULL)
        deleteList(start->next);
    free(start);
}

ListNode *stitchList(ListNode *array[])
{
    int i;
    ListNode *list, *current;
    list = newList();

    for (i = 0; i < 10; i++)
    {

        current = array[i];
        while (current->next != NULL)
        {
            current = current->next;
            list = insertAtTail(list, current->data);
        }
        deleteList(array[i]);
        array[i] = newList();
    }

    return list;
}

void printBucket(ListNode *array[])
{
    int i;
    for (i = 0; i < 10; i++)
    {
        printf("Bucket[%i]: ", i);
        printList(array[i]);
    }
}

int main(int argc, char **argv)
{
    int seed, NumVals, low, high, i, j, maxNum, N, listLength, digit, base = 1;
    ListNode *list[B], *unsortedList, *numList;

    if (argc != 5)
    {
        printf("Arguments error. Please check the input.\n");
        exit(-1);
    }

    seed = atoi(argv[1]);
    NumVals = atoi(argv[2]);
    low = atoi(argv[3]);
    high = atoi(argv[4]);

    if(seed < 0 || NumVals < 0 || low < 0 || high < 0 || low > high){
        printf("Input error. Please check the input.");
        exit(-1);
    }

    srand(seed);

    for (i = 0; i < 10; i++)
    {
        list[i] = newList();
    }

    unsortedList = newList();
    unsortedList = getRandomList(unsortedList, seed, NumVals, low, high);
    printf("The unsorted list is: \n");
    printList(unsortedList);
    maxNum = findMax(unsortedList);
    N = findN(maxNum);
    listLength = length(unsortedList);

    printf("The length is %i\n", listLength);
    printf("\n");

    numList = unsortedList;

    for (i = 0; i < N; i++)
    {
        ListNode *old;
        for (j = 0; j < listLength; j++)
        {
            ListNode *cur;
            cur = removeNode(numList);
            digit = cur->data % (base * 10) / base;
            list[digit] = insertAtTail(list[digit], cur->data);

            free(cur);
        }
        base *= 10;

        printBucket(list);
        old = numList;
        numList = stitchList(list);
        free(old);
        printList(numList);
    }

    for (i = 0; i < 10; i++)
    {
        deleteList(list[i]);
    }

    deleteList(numList);
    return 0;
}
